OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "Escriu en un nou comentari...",
    "Delete comment" : "Esborrar comentari",
    "Post" : "Publica",
    "Cancel" : "Cancel·la",
    "Edit comment" : "Editar comentari",
    "[Deleted user]" : "[usuari Esborrat]",
    "Comments" : "Comentaris",
    "No other comments available" : "No hi han altres comentaris disponibles",
    "More comments..." : "Més comentaris",
    "Save" : "Desa",
    "Allowed characters {count} of {max}" : "caracters Permessos {count} de {max}",
    "{count} unread comments" : "{count} comentaris no llegits",
    "Comment" : "Comentari",
    "<strong>Comments</strong> for files <em>(always listed in stream)</em>" : "<strong>Comentaris</strong> per arxius <em>(sempre llistat en corrent)",
    "You commented" : "Has comentat",
    "%1$s commented" : "%1$s comentat",
    "You commented on %2$s" : "Has comentat a %2$s",
    "%1$s commented on %2$s" : "%1$s ha comentat a %2$s"
},
"nplurals=2; plural=(n != 1);");
