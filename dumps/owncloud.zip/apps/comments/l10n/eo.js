OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "Tajpu novan komenton...",
    "Delete comment" : "Forigi komenton",
    "Post" : "Afiŝi",
    "Cancel" : "Nuligi",
    "Edit comment" : "Redakti komenton",
    "[Deleted user]" : "[Forigita uzanto]",
    "Comments" : "Komentoj",
    "No other comments available" : "Neniu alia komento disponeblas",
    "More comments..." : "Pli da komentoj...",
    "Save" : "Konservi",
    "Allowed characters {count} of {max}" : "Permesataj karakteroj: {count} el {max}",
    "{count} unread comments" : "{count} nelegitaj komentoj",
    "Comment" : "Komento",
    "%1$s commented" : "%1$s komentis",
    "%1$s commented on %2$s" : "%1$s komentis %2$s"
},
"nplurals=2; plural=(n != 1);");
