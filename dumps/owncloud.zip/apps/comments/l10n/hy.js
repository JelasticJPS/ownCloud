OC.L10N.register(
    "comments",
    {
    "Delete comment" : "Ջնջել մեկնաբանությունը",
    "Cancel" : "Չեղարկել",
    "Edit comment" : "Խմբագրել մեկնաբանությունը",
    "Comments" : "Մեկնաբանություններ",
    "Save" : "Պահպանել",
    "Comment" : "Մեկնաբանել",
    "You commented" : "Դու մեկնաբանեցիր",
    "%1$s commented" : "%1$s մեկնաբանեց"
},
"nplurals=2; plural=(n != 1);");
