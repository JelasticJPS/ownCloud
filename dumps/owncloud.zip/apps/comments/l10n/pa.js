OC.L10N.register(
    "comments",
    {
    "Cancel" : "ਰੱਦ ਕਰੋ"
},
"nplurals=2; plural=(n != 1);");
