OC.L10N.register(
    "comments",
    {
    "Cancel" : "Ezeztatu",
    "Save" : "Gorde",
    "Comment" : "Iruzkina"
},
"nplurals=2; plural=(n != 1);");
