OC.L10N.register(
    "comments",
    {
    "Cancel" : "Откажи",
    "Save" : "Сними",
    "Comment" : "Коментар",
    "%1$s commented" : "%1$s коментиран"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
