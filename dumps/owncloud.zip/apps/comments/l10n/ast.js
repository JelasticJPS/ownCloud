OC.L10N.register(
    "comments",
    {
    "Cancel" : "Encaboxar",
    "Save" : "Guardar",
    "Comment" : "Comentariu"
},
"nplurals=2; plural=(n != 1);");
