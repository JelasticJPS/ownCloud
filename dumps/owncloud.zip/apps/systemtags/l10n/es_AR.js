OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Etiquetas",
    "Name" : "Nombre",
    "Size" : "Tamaño",
    "Modified" : "Modificado"
},
"nplurals=2; plural=(n != 1);");
