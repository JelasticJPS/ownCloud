OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Etiquetas",
    "No files in here" : "Aquí non hai ficheiros",
    "No entries found in this folder" : "Non se atoparon entradas neste cartafol",
    "Name" : "Nome",
    "Size" : "Tamaño",
    "Modified" : "Modificado"
},
"nplurals=2; plural=(n != 1);");
