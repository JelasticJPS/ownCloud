OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Thẻ",
    "No entries found in this folder" : "Chưa có mục nào trong thư mục",
    "Name" : "Tên",
    "Size" : "Kích cỡ",
    "Modified" : "Thay đổi"
},
"nplurals=1; plural=0;");
