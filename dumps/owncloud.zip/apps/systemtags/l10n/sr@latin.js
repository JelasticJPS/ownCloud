OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Oznake",
    "No files in here" : "Ovde nema fajlova",
    "No entries found in this folder" : "Nema ničega u ovoj fascikli",
    "Name" : "naziv",
    "Size" : "veličina",
    "Modified" : "Izmenjen"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
