OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Tag",
    "No files in here" : "Tidak ada berkas disini",
    "No entries found in this folder" : "Tidak ada entri yang ditemukan dalam folder ini",
    "Name" : "Nama",
    "Size" : "Ukuran",
    "Modified" : "Dimodifikasi"
},
"nplurals=1; plural=0;");
