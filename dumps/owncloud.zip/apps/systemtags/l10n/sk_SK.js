OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Značky",
    "No files in here" : "Nie sú tu žiadne súbory",
    "No entries found in this folder" : "V tomto priečinku nebolo nič nájdené",
    "Name" : "Názov",
    "Size" : "Veľkosť",
    "Modified" : "Upravené"
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");
