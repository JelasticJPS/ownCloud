OC.L10N.register(
    "systemtags",
    {
    "Tags" : "ট্যাগ",
    "Name" : "নাম",
    "Size" : "আকার",
    "Modified" : "পরিবর্তিত"
},
"nplurals=2; plural=(n != 1);");
