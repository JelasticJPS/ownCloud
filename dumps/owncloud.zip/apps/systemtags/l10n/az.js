OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Işarələr",
    "No files in here" : "Burda fayl yoxdur",
    "No entries found in this folder" : "Bu qovluqda heç bir verilən tapılmadı",
    "Name" : "Ad",
    "Size" : "Həcm",
    "Modified" : "Dəyişdirildi"
},
"nplurals=2; plural=(n != 1);");
