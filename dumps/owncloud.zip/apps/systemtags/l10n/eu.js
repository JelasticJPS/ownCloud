OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Etiketak",
    "No entries found in this folder" : "Ez da sarrerarik aurkitu karpeta honetan",
    "Name" : "Izena",
    "Size" : "Tamaina",
    "Modified" : "Aldatuta"
},
"nplurals=2; plural=(n != 1);");
