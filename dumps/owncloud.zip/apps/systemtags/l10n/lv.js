OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Birkas",
    "No entries found in this folder" : "Šajā mapē nekas nav atrasts",
    "Name" : "Nosaukums",
    "Size" : "Izmērs",
    "Modified" : "Mainīts"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
