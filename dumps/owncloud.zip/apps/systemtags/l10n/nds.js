OC.L10N.register(
    "systemtags",
    {
    "Name" : "Name"
},
"nplurals=2; plural=(n != 1);");
