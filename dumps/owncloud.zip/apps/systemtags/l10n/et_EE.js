OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Sildid",
    "Tagged files" : "Sildistatud failid",
    "Select tags to filter by" : "Vali sildid, mille järgi filtreerida",
    "%s (restricted)" : "%s (piiratud)",
    "%s (invisible)" : "%s (nähtamatu)",
    "No files in here" : "Siin ei ole faile",
    "No entries found in this folder" : "Selles kaustast ei leitud kirjeid",
    "Name" : "Nimi",
    "Size" : "Suurus",
    "Modified" : "Muudetud"
},
"nplurals=2; plural=(n != 1);");
