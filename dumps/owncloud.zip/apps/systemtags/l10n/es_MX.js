OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Etiquetas",
    "Tagged files" : "Archivos etiquetados",
    "Select tags to filter by" : "Seleccionar etiquetas con las cuales filtrar",
    "Please select tags to filter by" : "Por favor selecciona las etiquetas con las cuales filtrar",
    "No files in here" : "No hay archivos aquí",
    "No entries found in this folder" : "No se encontraron entradas en esta carpeta",
    "Name" : "Nombre",
    "Size" : "Tamaño",
    "Modified" : "Modificado"
},
"nplurals=2; plural=(n != 1);");
