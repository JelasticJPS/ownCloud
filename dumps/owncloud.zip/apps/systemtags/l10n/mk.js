OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Ознаки",
    "No files in here" : "Тука нема датотеки",
    "No entries found in this folder" : "Нема ништо во оваа папка",
    "Name" : "Име",
    "Size" : "Големина",
    "Modified" : "Променето"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
