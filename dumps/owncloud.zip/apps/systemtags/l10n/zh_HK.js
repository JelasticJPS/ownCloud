OC.L10N.register(
    "systemtags",
    {
    "Tags" : "標籤",
    "Name" : "名稱",
    "Size" : "大小"
},
"nplurals=1; plural=0;");
