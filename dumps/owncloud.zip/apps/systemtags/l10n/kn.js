OC.L10N.register(
    "systemtags",
    {
    "Name" : "﻿ಹೆಸರು",
    "Size" : "﻿ ಗಾತ್ರ",
    "Modified" : "﻿ಬದಲಾಯಿಸಿದ"
},
"nplurals=1; plural=0;");
