OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Tunnisteet",
    "Tagged files" : "Tunnisteella merkityt tiedostot",
    "Select tags to filter by" : "Valitse suodatettavat tunnisteet",
    "Please select tags to filter by" : "Valitse suodatettavat tunnisteet",
    "No files found for the selected tags" : "Tiedostoja ei löytynyt valituilla tunnisteilla",
    "<strong>System tags</strong> for a file have been modified" : "Tiedoston <strong>järjestelmätunnisteita</strong> on muokattu",
    "%s (invisible)" : "%s (näkymätön)",
    "No files in here" : "Täällä ei ole tiedostoja",
    "No entries found in this folder" : "Ei kohteita tässä kansiossa",
    "Name" : "Nimi",
    "Size" : "Koko",
    "Modified" : "Muokattu"
},
"nplurals=2; plural=(n != 1);");
