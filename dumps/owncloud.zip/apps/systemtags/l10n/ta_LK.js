OC.L10N.register(
    "systemtags",
    {
    "Tags" : "சீட்டுகள்",
    "Name" : "பெயர்",
    "Size" : "அளவு",
    "Modified" : "மாற்றப்பட்டது"
},
"nplurals=2; plural=(n != 1);");
