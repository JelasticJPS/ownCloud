OC.L10N.register(
    "systemtags",
    {
    "Tags" : "ტაგები",
    "Name" : "სახელი",
    "Size" : "ზომა",
    "Modified" : "შეცვლილია"
},
"nplurals=1; plural=0;");
