OC.L10N.register(
    "systemtags",
    {
    "Name" : "పేరు",
    "Size" : "పరిమాణం"
},
"nplurals=2; plural=(n != 1);");
