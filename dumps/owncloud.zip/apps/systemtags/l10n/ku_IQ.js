OC.L10N.register(
    "systemtags",
    {
    "Tags" : "تاگه‌کان",
    "Name" : "ناو"
},
"nplurals=2; plural=(n != 1);");
