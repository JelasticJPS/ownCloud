OC.L10N.register(
    "systemtags",
    {
    "Tags" : "بەلگەلەر",
    "Name" : "ئاتى",
    "Size" : "چوڭلۇقى",
    "Modified" : "ئۆزگەرتكەن"
},
"nplurals=1; plural=0;");
