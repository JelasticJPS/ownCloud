OC.L10N.register(
    "systemtags",
    {
    "Tags" : "ටැග",
    "Name" : "නම",
    "Size" : "ප්‍රමාණය",
    "Modified" : "වෙනස් කළ"
},
"nplurals=2; plural=(n != 1);");
