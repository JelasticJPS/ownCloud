OC.L10N.register(
    "systemtags",
    {
    "Tags" : "ស្លាក",
    "Name" : "ឈ្មោះ",
    "Size" : "ទំហំ",
    "Modified" : "បាន​កែ​ប្រែ"
},
"nplurals=1; plural=0;");
