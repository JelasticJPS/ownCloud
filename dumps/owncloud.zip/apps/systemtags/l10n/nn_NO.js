OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Emneord",
    "Name" : "Namn",
    "Size" : "Storleik",
    "Modified" : "Endra"
},
"nplurals=2; plural=(n != 1);");
