OC.L10N.register(
    "systemtags",
    {
    "Tags" : "ট্যাগ্স",
    "Name" : "নাম",
    "Size" : "আকার"
},
"nplurals=2; plural=(n != 1);");
