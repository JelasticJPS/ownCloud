OC.L10N.register(
    "systemtags",
    {
    "Tags" : "標籤",
    "No files in here" : "沒有任何檔案",
    "No entries found in this folder" : "在此資料夾中沒有任何項目",
    "Name" : "名稱",
    "Size" : "大小",
    "Modified" : "修改時間"
},
"nplurals=1; plural=0;");
