OC.L10N.register(
    "systemtags",
    {
    "Name" : "Nama",
    "Size" : "Saiz",
    "Modified" : "Dimodifikasi"
},
"nplurals=1; plural=0;");
