OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Etiquettas",
    "Name" : "Nomine",
    "Size" : "Dimension",
    "Modified" : "Modificate"
},
"nplurals=2; plural=(n != 1);");
