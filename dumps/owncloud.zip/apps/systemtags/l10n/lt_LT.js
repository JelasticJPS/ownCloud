OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Žymės",
    "Tagged files" : "Pažymėti failai",
    "No files in here" : "Čia nėra failų",
    "No entries found in this folder" : "Nerasta įrašų šiame aplanke",
    "Name" : "Pavadinimas",
    "Size" : "Dydis",
    "Modified" : "Pakeista"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");
