OC.L10N.register(
    "systemtags",
    {
    "Tags" : "Պիտակներ",
    "No files in here" : "Ֆայլեր չկան այստեղ",
    "No entries found in this folder" : "Պանակում մուտքին համապատասխանող ոչինչ չգտնվեց",
    "Name" : "Անուն",
    "Size" : "Չափս",
    "Modified" : "Փոփոխված"
},
"nplurals=2; plural=(n != 1);");
