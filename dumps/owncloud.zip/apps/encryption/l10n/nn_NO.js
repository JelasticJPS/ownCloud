OC.L10N.register(
    "encryption",
    {
    "The share will expire on %s." : "Deling har gyldigheit til %s.",
    "Cheers!" : "Skål!"
},
"nplurals=2; plural=(n != 1);");
