OC.L10N.register(
    "encryption",
    {
    "Encryption" : "شىفىرلاش"
},
"nplurals=1; plural=0;");
