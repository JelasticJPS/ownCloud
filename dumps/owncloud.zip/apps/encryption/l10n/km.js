OC.L10N.register(
    "encryption",
    {
    "Password successfully changed." : "បាន​ប្ដូរ​ពាក្យ​សម្ងាត់​ដោយ​ជោគជ័យ។",
    "Could not change the password. Maybe the old password was not correct." : "មិន​អាច​ប្ដូរ​ពាក្យ​សម្ងាត់​បាន​ទេ។ ប្រហែល​ពាក្យ​សម្ងាត់​ចាស់​មិន​ត្រឹម​ត្រូវ។",
    "Change Password" : "ប្ដូរ​ពាក្យ​សម្ងាត់",
    "Enabled" : "បាន​បើក",
    "Disabled" : "បាន​បិទ"
},
"nplurals=1; plural=0;");
