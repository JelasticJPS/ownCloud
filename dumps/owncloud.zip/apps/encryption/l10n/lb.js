OC.L10N.register(
    "encryption",
    {
    "Cheers!" : "Prost!",
    "Change Password" : "Passwuert änneren",
    "Enabled" : "Aktivéiert",
    "Disabled" : "Deaktivéiert"
},
"nplurals=2; plural=(n != 1);");
