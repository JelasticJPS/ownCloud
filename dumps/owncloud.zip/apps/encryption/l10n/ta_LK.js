OC.L10N.register(
    "encryption",
    {
    "Encryption" : "மறைக்குறியீடு"
},
"nplurals=2; plural=(n != 1);");
