OC.L10N.register(
    "encryption",
    {
    "Encryption" : "ගුප්ත කේතනය"
},
"nplurals=2; plural=(n != 1);");
