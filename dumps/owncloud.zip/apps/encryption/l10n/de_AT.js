OC.L10N.register(
    "encryption",
    {
    "The share will expire on %s." : "Die Freigabe wird am %s ablaufen.",
    "Cheers!" : "Noch einen schönen Tag!"
},
"nplurals=2; plural=(n != 1);");
