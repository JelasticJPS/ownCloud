OC.L10N.register(
    "encryption",
    {
    "Change Password" : "更改密碼",
    "Enabled" : "啟用",
    "Disabled" : "停用"
},
"nplurals=1; plural=0;");
